
DROP TABLE IF EXISTS `sw_tipo_rubrica`;
CREATE TABLE `sw_tipo_rubrica` (
  `id_tipo_rubrica` int(11) NOT NULL,
  `tr_descripcion` varchar(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `sw_tipo_rubrica` (`id_tipo_rubrica`, `tr_descripcion`) VALUES
(1, 'OBLIGATORIO'),
(2, 'OPCIONAL');

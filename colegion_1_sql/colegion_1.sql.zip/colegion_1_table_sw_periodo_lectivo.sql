
DROP TABLE IF EXISTS `sw_periodo_lectivo`;
CREATE TABLE `sw_periodo_lectivo` (
  `id_periodo_lectivo` int(11) NOT NULL,
  `id_periodo_estado` int(11) NOT NULL,
  `id_institucion` int(11) NOT NULL,
  `pe_anio_inicio` int(11) NOT NULL,
  `pe_anio_fin` int(11) NOT NULL,
  `pe_estado` char(1) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `pe_fecha_inicio` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sw_periodo_lectivo` (`id_periodo_lectivo`, `id_periodo_estado`, `id_institucion`, `pe_anio_inicio`, `pe_anio_fin`, `pe_estado`, `pe_fecha_inicio`) VALUES
(1, 2, 1, 2013, 2014, 'T', '2013-09-02'),
(2, 2, 1, 2014, 2015, 'T', '2014-09-01'),
(3, 2, 1, 2015, 2016, 'T', '2015-09-01'),
(4, 2, 1, 2016, 2017, 'T', '2016-09-01'),
(5, 2, 1, 2017, 2018, 'T', '2017-09-04'),
(6, 1, 1, 2018, 2019, 'A', '2018-09-03');

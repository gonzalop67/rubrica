
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_perfil`
--

DROP TABLE IF EXISTS `sw_perfil`;
CREATE TABLE `sw_perfil` (
  `id_perfil` int(11) NOT NULL,
  `pe_nombre` varchar(16) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `pe_nivel_acceso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_perfil`
--

INSERT INTO `sw_perfil` (`id_perfil`, `pe_nombre`, `pe_nivel_acceso`) VALUES
(1, 'Administrador', 3),
(2, 'Docente', 2),
(3, 'Secretaría', 2),
(5, 'Inspección', 2),
(6, 'Autoridad', 3),
(7, 'Tutor', 2),
(8, 'DECE', 2),
(10, 'Estudiante', 0);

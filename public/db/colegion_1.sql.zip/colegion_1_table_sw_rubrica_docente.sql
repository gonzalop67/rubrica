
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_rubrica_docente`
--

DROP TABLE IF EXISTS `sw_rubrica_docente`;
CREATE TABLE `sw_rubrica_docente` (
  `id_rubrica_evaluacion` int(11) NOT NULL,
  `id_criterio_personalizado` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_asignatura` int(11) NOT NULL,
  `id_paralelo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_rubrica_docente`
--

INSERT INTO `sw_rubrica_docente` (`id_rubrica_evaluacion`, `id_criterio_personalizado`, `id_usuario`, `id_asignatura`, `id_paralelo`) VALUES
(1, 1, 5, 14, 10),
(1, 2, 5, 14, 10),
(1, 3, 5, 14, 10),
(1, 4, 5, 14, 10),
(2, 5, 5, 14, 10),
(2, 6, 5, 14, 10),
(2, 7, 5, 14, 10),
(2, 8, 5, 14, 10),
(3, 9, 5, 14, 10),
(3, 10, 5, 14, 10),
(3, 11, 5, 14, 10),
(3, 12, 5, 14, 10),
(4, 13, 5, 14, 10),
(4, 14, 5, 14, 10),
(4, 15, 5, 14, 10),
(4, 16, 5, 14, 10),
(5, 17, 5, 14, 10),
(1, 18, 5, 15, 10),
(1, 19, 5, 15, 10),
(1, 20, 5, 15, 10),
(1, 21, 5, 15, 10),
(2, 22, 5, 15, 10),
(2, 23, 5, 15, 10),
(2, 24, 5, 15, 10),
(2, 25, 5, 15, 10);

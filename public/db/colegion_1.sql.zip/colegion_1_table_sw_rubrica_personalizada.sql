
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_rubrica_personalizada`
--

DROP TABLE IF EXISTS `sw_rubrica_personalizada`;
CREATE TABLE `sw_rubrica_personalizada` (
  `id_rubrica_personalizada` int(11) NOT NULL,
  `id_rubrica_evaluacion` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_asignatura` int(11) NOT NULL,
  `id_paralelo` int(11) NOT NULL,
  `rp_tema` varchar(64) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `rp_fec_envio` date NOT NULL,
  `rp_fec_evaluacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_rubrica_personalizada`
--

INSERT INTO `sw_rubrica_personalizada` (`id_rubrica_personalizada`, `id_rubrica_evaluacion`, `id_usuario`, `id_asignatura`, `id_paralelo`, `rp_tema`, `rp_fec_envio`, `rp_fec_evaluacion`) VALUES
(1, 1, 5, 14, 10, 'ALGORITMOS Y PROGRAMAS', '2013-09-10', '2013-09-17'),
(2, 2, 5, 14, 10, 'ALGORITMOS DE LA VIDA DIARIA', '2013-09-18', '2013-09-25'),
(3, 3, 5, 14, 10, 'FASES DE LA PROGRAMACION', '2013-10-02', '2013-10-09'),
(4, 4, 5, 14, 10, 'ALGORITMOS Y FASES DE PROGRAMACION', '2013-10-16', '2013-10-23'),
(5, 5, 5, 14, 10, 'UT1: ALGORITMOS Y PROGRAMAS', '2013-10-16', '2013-10-16'),
(8, 1, 5, 15, 10, 'DIAGRAMA DE LA PLACA BASE', '2013-09-09', '2013-09-16'),
(9, 2, 5, 15, 10, 'FORMATOS DE LA PLACA BASE', '2013-09-23', '2013-09-30');

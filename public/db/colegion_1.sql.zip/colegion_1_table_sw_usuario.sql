
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_usuario`
--

DROP TABLE IF EXISTS `sw_usuario`;
CREATE TABLE `sw_usuario` (
  `id_usuario` int(11) NOT NULL,
  `us_titulo` varchar(8) NOT NULL,
  `us_apellidos` varchar(32) NOT NULL,
  `us_nombres` varchar(32) NOT NULL,
  `us_shortname` varchar(45) NOT NULL,
  `us_fullname` varchar(64) NOT NULL,
  `us_login` varchar(24) NOT NULL,
  `us_password` varchar(64) NOT NULL,
  `us_foto` varchar(100) NOT NULL,
  `us_genero` varchar(1) NOT NULL,
  `us_activo` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `sw_usuario`
--

INSERT INTO `sw_usuario` (`id_usuario`, `us_titulo`, `us_apellidos`, `us_nombres`, `us_shortname`, `us_fullname`, `us_login`, `us_password`, `us_foto`, `us_genero`, `us_activo`) VALUES
(1, 'Ing.', 'Peñaherrera Escobar', 'Gonzalo Nicolás', 'Ing. Gonzalo Peñaherrera', 'Peñaherrera Escobar Gonzalo Nicolás', 'Administrador', 'eDuVVtAzH2Qf', '855136358.jpg', 'M', 1),
(2, 'Tlgo.', 'Cabascango Herrera', 'Milton Fabián', 'Tlgo. Milton Cabascango', 'Cabascango Herrera Milton Fabián', 'miltonc', 'UiLAAKw4HDM=', '1920377357.jpg', 'M', 1),
(3, 'Ing.', 'Peñaherrera Escobar', 'Gonzalo Nicolás', 'Ing. Gonzalo Peñaherrera', 'Peñaherrera Escobar Gonzalo Nicolás', 'gonzalop', 'eDuVVtAzH2Qf', '990894859.png', 'M', 1),
(4, 'Ing.', 'Benavides Ortiz', 'German Gustavo', 'Ing. German Benavides', 'Benavides Ortiz German Gustavo', 'germanb', 'WC7RDPxvSTMLzBDf', '183631556.jpg', 'M', 1),
(5, 'Lic.', 'Calero Navarrete', 'Elmo Eduardo', 'Lic. Elmo Calero', 'Calero Navarrete Elmo Eduardo', 'elmoc', 'WifODvNuX2BI', '1332781677.jpg', 'M', 1),
(6, 'Lic.', 'Cedeño Zambrano', 'Edith Monserrate', 'Lic. Edith Cedeño', 'Cedeño Zambrano Edith Monserrate', 'edithc', 'ciTNEvhzWWBPmxbG', '1130818136.jpg', 'F', 1),
(7, 'Dr.', 'Enríquez Martínez', 'Carlos Alberto', 'Dr. Carlos Enríquez', 'Enríquez Martínez Carlos Alberto', 'CARLOSE', 'XCrRDfJyTjkLxg==', '1133505079.png', 'M', 1),
(8, 'Dr.', 'Guamán Calderón', 'Luis Alfredo', 'Dr. Luis Guamán', 'Guamán Calderón Luis Alfredo', 'luisg', 'WS7RD/xvT24=', '1945146505.png', 'M', 1),
(9, 'Lic.', 'Mejía Segarra', 'Rómulo Oswaldo', 'Lic. Rómulo Mejía', 'Mejía Segarra Rómulo Oswaldo', 'romulom', 'TSTOFPFuRg==', '43729064.jpg', 'M', 1),
(10, 'Lic.', 'Montenegro Yépez', 'Jaime Efrén', 'Lic. Jaime Montenegro', 'Montenegro Yépez Jaime Efrén', 'efrenm', 'Wi3RBPMw', '2117906686.jpg', 'M', 1),
(11, 'MSc.', 'Proaño Estrella', 'Wilson Eduardo', 'MSc. Wilson Proaño', 'Proaño Estrella Wilson Eduardo', 'wilsonp', 'Wi/WAO9lRHEJzhLEvA==', '1926558213.jpg', 'M', 1),
(12, 'MSc.', 'Rosero Medina', 'Roberto Hernán', 'MSc. Roberto Rosero', 'Rosero Medina Roberto Hernán', 'robertos', 'TSTBBO91RHIJzhLExTw=', '1180374851.jpg', 'M', 1),
(13, 'Lic.', 'Salazar Ordoñez', 'Carmen Alicia', 'Lic. Carmen Salazar', 'Salazar Ordoñez Carmen Alicia', 'alicias', 'XibBAO8=', '1071121085.jpg', 'F', 1),
(14, 'Lic.', 'Salgado Araujo', 'María del Rosario', 'Lic. María Salgado', 'Salgado Araujo María del Rosario', 'rosarios', 'TSrFAPhtSg==', '139409125.png', 'F', 1),
(15, 'MSc.', 'Sanmartín Vásquez', 'Sandra Verónica', 'MSc. Sandra Sanmartín', 'Sanmartín Vásquez Sandra Verónica', 'veronicas', 'SS7RDvNoSGBIzBDHp0X8', '151227869.png', 'F', 1),
(16, 'Lic.', 'Trujillo Realpe', 'William Oswaldo', 'Lic. William Trujillo', 'Trujillo Realpe William Oswaldo', 'williamt', 'cDjUAPFlRDACyRTY', '576934223.jpg', 'M', 1),
(17, 'Lic.', 'Zambrano Cedeño', 'Walter Adbón', 'Lic. Walter Zambrano', 'Zambrano Cedeño Walter Adbón', 'walterz', 'cirbCOluGTEJzg==', '205265583.jpg', 'M', 1);

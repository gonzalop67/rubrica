
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_especialidad`
--

DROP TABLE IF EXISTS `sw_especialidad`;
CREATE TABLE `sw_especialidad` (
  `id_especialidad` int(11) NOT NULL,
  `id_tipo_educacion` int(11) NOT NULL,
  `es_nombre` varchar(64) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `es_figura` varchar(50) NOT NULL,
  `es_abreviatura` varchar(15) NOT NULL,
  `es_orden` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

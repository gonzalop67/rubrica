
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_periodo_lectivo`
--

DROP TABLE IF EXISTS `sw_periodo_lectivo`;
CREATE TABLE `sw_periodo_lectivo` (
  `id_periodo_lectivo` int(11) NOT NULL,
  `id_periodo_estado` int(11) NOT NULL,
  `id_modalidad` int(11) NOT NULL,
  `pe_anio_inicio` int(5) NOT NULL,
  `pe_anio_fin` int(5) NOT NULL,
  `pe_fecha_inicio` date NOT NULL,
  `pe_fecha_fin` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `sw_periodo_lectivo`
--

INSERT INTO `sw_periodo_lectivo` (`id_periodo_lectivo`, `id_periodo_estado`, `id_modalidad`, `pe_anio_inicio`, `pe_anio_fin`, `pe_fecha_inicio`, `pe_fecha_fin`) VALUES
(1, 1, 1, 2021, 2022, '0000-00-00', '0000-00-00');

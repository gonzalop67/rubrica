
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_periodo_evaluacion`
--

DROP TABLE IF EXISTS `sw_periodo_evaluacion`;
CREATE TABLE `sw_periodo_evaluacion` (
  `id_periodo_evaluacion` int(11) NOT NULL,
  `id_periodo_lectivo` int(11) NOT NULL,
  `pe_nombre` varchar(24) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_periodo_evaluacion`
--

INSERT INTO `sw_periodo_evaluacion` (`id_periodo_evaluacion`, `id_periodo_lectivo`, `pe_nombre`) VALUES
(1, 1, 'PRIMER QUIMESTRE'),
(2, 1, 'SEGUNDO QUIMESTRE'),
(3, 1, 'SUPLETORIO'),
(4, 1, 'REMEDIAL'),
(5, 1, 'DE GRACIA');

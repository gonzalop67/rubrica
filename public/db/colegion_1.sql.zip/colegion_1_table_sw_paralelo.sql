
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_paralelo`
--

DROP TABLE IF EXISTS `sw_paralelo`;
CREATE TABLE `sw_paralelo` (
  `id_paralelo` int(11) NOT NULL,
  `id_curso` int(11) NOT NULL,
  `pa_nombre` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_paralelo`
--

INSERT INTO `sw_paralelo` (`id_paralelo`, `id_curso`, `pa_nombre`) VALUES
(1, 1, 'A'),
(2, 2, 'A'),
(3, 2, 'B'),
(4, 3, 'A'),
(5, 3, 'B'),
(6, 4, 'A'),
(7, 5, 'A'),
(8, 6, 'A'),
(9, 6, 'B'),
(10, 7, 'C1'),
(11, 7, 'C2'),
(12, 8, 'C1'),
(13, 8, 'C2'),
(14, 9, 'C1'),
(15, 9, 'C2'),
(16, 9, 'C3');

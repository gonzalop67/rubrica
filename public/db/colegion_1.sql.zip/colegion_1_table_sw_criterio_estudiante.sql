
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_criterio_estudiante`
--

DROP TABLE IF EXISTS `sw_criterio_estudiante`;
CREATE TABLE `sw_criterio_estudiante` (
  `id_criterio_estudiante` int(11) NOT NULL,
  `id_rubrica_estudiante` int(11) NOT NULL,
  `id_criterio_personalizado` int(11) NOT NULL,
  `ce_calificacion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

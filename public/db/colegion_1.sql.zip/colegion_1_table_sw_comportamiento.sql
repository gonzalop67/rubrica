
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_comportamiento`
--

DROP TABLE IF EXISTS `sw_comportamiento`;
CREATE TABLE `sw_comportamiento` (
  `id_paralelo` int(11) NOT NULL,
  `id_estudiante` int(11) NOT NULL,
  `id_periodo_evaluacion` int(11) NOT NULL,
  `id_indice_evaluacion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `sw_comportamiento`
--

INSERT INTO `sw_comportamiento` (`id_paralelo`, `id_estudiante`, `id_periodo_evaluacion`, `id_indice_evaluacion`) VALUES
(1, 182, 1, 1),
(1, 183, 1, 2),
(1, 184, 1, 3),
(1, 185, 1, 4),
(1, 186, 1, 5),
(1, 187, 1, 6),
(1, 188, 1, 7),
(1, 189, 1, 8),
(1, 190, 1, 9),
(1, 204, 1, 10),
(1, 191, 1, 11),
(1, 192, 1, 12),
(1, 193, 1, 13),
(1, 194, 1, 14),
(1, 195, 1, 15),
(1, 196, 1, 16),
(1, 197, 1, 17),
(1, 198, 1, 18),
(1, 199, 1, 19),
(1, 200, 1, 20),
(1, 201, 1, 21),
(1, 202, 1, 22),
(1, 203, 1, 23);

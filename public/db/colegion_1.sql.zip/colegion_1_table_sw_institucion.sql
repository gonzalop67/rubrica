
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_institucion`
--

DROP TABLE IF EXISTS `sw_institucion`;
CREATE TABLE `sw_institucion` (
  `id_institucion` int(11) UNSIGNED NOT NULL,
  `in_nombre` varchar(64) NOT NULL,
  `in_direccion` varchar(64) NOT NULL,
  `in_telefono1` varchar(64) NOT NULL,
  `in_nom_rector` varchar(45) NOT NULL,
  `in_nom_vicerrector` varchar(45) NOT NULL,
  `in_nom_secretario` varchar(45) NOT NULL,
  `in_url` varchar(64) NOT NULL,
  `in_logo` varchar(64) NOT NULL,
  `in_amie` varchar(16) NOT NULL,
  `in_ciudad` varchar(64) NOT NULL,
  `in_copiar_y_pegar` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `sw_institucion`
--

INSERT INTO `sw_institucion` (`id_institucion`, `in_nombre`, `in_direccion`, `in_telefono1`, `in_nom_rector`, `in_nom_vicerrector`, `in_nom_secretario`, `in_url`, `in_logo`, `in_amie`, `in_ciudad`, `in_copiar_y_pegar`) VALUES
(1, 'UNIDAD EDUCATIVA PCEI FISCAL SALAMANCA', 'Calle el Tiempo y Pasaje Mónaco', '2256311/2254818', 'MSc. Wilson Proaño', 'Lic. Rómulo Mejía', 'MSc. Verónica Sanmartín', 'http://colegionocturnosalamanca.com', 'logo_salamanca.gif', '17H00215', 'Quito D.M.', 0);

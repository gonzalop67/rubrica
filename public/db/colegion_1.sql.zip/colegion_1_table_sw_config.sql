
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_config`
--

DROP TABLE IF EXISTS `sw_config`;
CREATE TABLE `sw_config` (
  `dir_raiz` varchar(16) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_config`
--

INSERT INTO `sw_config` (`dir_raiz`) VALUES
('rubrica/');


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_rubrica_evaluacion`
--

DROP TABLE IF EXISTS `sw_rubrica_evaluacion`;
CREATE TABLE `sw_rubrica_evaluacion` (
  `id_rubrica_evaluacion` int(11) NOT NULL,
  `id_aporte_evaluacion` int(11) NOT NULL,
  `ru_nombre` varchar(24) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `ru_abreviatura` varchar(5) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_rubrica_evaluacion`
--

INSERT INTO `sw_rubrica_evaluacion` (`id_rubrica_evaluacion`, `id_aporte_evaluacion`, `ru_nombre`, `ru_abreviatura`) VALUES
(1, 1, 'TRABAJOS ACADEMICOS', 'TA'),
(2, 1, 'ACTIVIDADES INDIVIDUALES', 'AI'),
(3, 1, 'ACTIVIDADES GRUPALES', 'AG'),
(4, 1, 'LECCIONES', 'L'),
(5, 1, 'EVALUACION SUMATIVA', 'EB1'),
(6, 2, 'TRABAJOS ACADEMICOS', 'TA'),
(7, 2, 'ACTIVIDADES INDIVIDUALES', 'AI'),
(8, 2, 'ACTIVIDADES GRUPALES', 'AG'),
(9, 2, 'LECCIONES', 'L'),
(10, 2, 'EVALUACION SUMATIVA', 'EB2'),
(11, 3, 'TRABAJOS ACADEMICOS', 'TA'),
(12, 3, 'ACTIVIDADES INDIVIDUALES', 'AI'),
(13, 3, 'ACTIVIDADES GRUPALES', 'AG'),
(14, 3, 'LECCIONES', 'L'),
(15, 3, 'EVALUACION SUMATIVA', 'EB3'),
(16, 4, 'EXAMEN QUIMESTRAL', 'EQ1'),
(17, 5, 'TRABAJOS ACADEMICOS', 'TA'),
(18, 5, 'ACTIVIDADES INDIVIDUALES', 'AI'),
(19, 5, 'ACTIVIDADES GRUPALES', 'AG'),
(20, 5, 'LECCIONES', 'L'),
(21, 5, 'EVALUACION SUMATIVA', 'EB1'),
(22, 6, 'TRABAJOS ACADEMICOS', 'TA'),
(23, 6, 'ACTIVIDADES INDIVIDUALES', 'AI'),
(24, 6, 'ACTIVIDADES GRUPALES', 'AG'),
(25, 6, 'LECCIONES', 'L'),
(26, 6, 'EVALUACION SUMATIVA', 'EB2'),
(27, 7, 'TRABAJOS ACADEMICOS', 'TA'),
(28, 7, 'ACTIVIDADES INDIVIDUALES', 'AI'),
(29, 7, 'ACTIVIDADES GRUPALES', 'AG'),
(30, 7, 'LECCIONES', 'L'),
(31, 7, 'EVALUACION SUMATIVA', 'EB3'),
(32, 8, 'EXAMEN QUIMESTRAL', 'EQ2'),
(33, 9, 'EXAMEN SUPLETORIO', 'SUPLE'),
(34, 10, 'EXAMEN REMEDIAL', 'REME'),
(35, 11, 'EXAMEN DE GRACIA', 'GRAC');

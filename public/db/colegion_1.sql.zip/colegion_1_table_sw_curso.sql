
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_curso`
--

DROP TABLE IF EXISTS `sw_curso`;
CREATE TABLE `sw_curso` (
  `id_curso` int(11) NOT NULL,
  `id_especialidad` int(11) NOT NULL,
  `cu_nombre` varchar(32) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_curso`
--

INSERT INTO `sw_curso` (`id_curso`, `id_especialidad`, `cu_nombre`) VALUES
(1, 1, 'OCTAVO DE BASICA'),
(2, 1, 'NOVENO DE BASICA'),
(3, 1, 'DECIMO DE BASICA'),
(4, 2, 'PRIMERO DE BACHILLERATO'),
(5, 2, 'SEGUNDO DE BACHILLERATO'),
(6, 2, 'TERCERO DE BACHILLERATO'),
(7, 3, 'PRIMERO DE BACHILLERATO'),
(8, 3, 'SEGUNDO DE BACHILLERATO'),
(9, 3, 'TERCERO DE BACHILLERATO');

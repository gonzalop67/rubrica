
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_usuario_perfil`
--

DROP TABLE IF EXISTS `sw_usuario_perfil`;
CREATE TABLE `sw_usuario_perfil` (
  `id_usuario` int(11) NOT NULL,
  `id_perfil` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_usuario_perfil`
--

INSERT INTO `sw_usuario_perfil` (`id_usuario`, `id_perfil`) VALUES
(1, 1),
(2, 2),
(2, 7),
(3, 2),
(3, 7),
(4, 2),
(4, 7),
(5, 2),
(5, 7),
(6, 2),
(6, 7),
(7, 2),
(7, 7),
(8, 2),
(8, 7),
(9, 2),
(9, 6),
(9, 7),
(10, 2),
(10, 7),
(11, 2),
(11, 6),
(12, 2),
(12, 7),
(13, 2),
(13, 7),
(14, 2),
(14, 7),
(15, 2),
(15, 3),
(15, 7),
(16, 2),
(16, 7),
(17, 2),
(17, 7);

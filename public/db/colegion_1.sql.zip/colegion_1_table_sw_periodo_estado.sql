
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_periodo_estado`
--

DROP TABLE IF EXISTS `sw_periodo_estado`;
CREATE TABLE `sw_periodo_estado` (
  `id_periodo_estado` int(11) UNSIGNED NOT NULL,
  `pe_descripcion` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `sw_periodo_estado`
--

INSERT INTO `sw_periodo_estado` (`id_periodo_estado`, `pe_descripcion`) VALUES
(1, 'ACTUAL'),
(2, 'TERMINADO');

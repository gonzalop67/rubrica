
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_indice_evaluacion`
--

DROP TABLE IF EXISTS `sw_indice_evaluacion`;
CREATE TABLE `sw_indice_evaluacion` (
  `id_indice_evaluacion` int(11) NOT NULL,
  `valores_t` float NOT NULL,
  `cum_norma_t` float NOT NULL,
  `pun_asiste_t` float NOT NULL,
  `presentacion_t` float NOT NULL,
  `valores_i` float NOT NULL,
  `cum_norma_i` float NOT NULL,
  `pun_asiste_i` float NOT NULL,
  `presentacion_i` float NOT NULL,
  `total` float NOT NULL,
  `promedio` float NOT NULL,
  `equivalencia` varchar(1) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `sw_indice_evaluacion`
--

INSERT INTO `sw_indice_evaluacion` (`id_indice_evaluacion`, `valores_t`, `cum_norma_t`, `pun_asiste_t`, `presentacion_t`, `valores_i`, `cum_norma_i`, `pun_asiste_i`, `presentacion_i`, `total`, `promedio`, `equivalencia`) VALUES
(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');

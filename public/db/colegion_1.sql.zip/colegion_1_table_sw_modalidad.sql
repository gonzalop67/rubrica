
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_modalidad`
--

DROP TABLE IF EXISTS `sw_modalidad`;
CREATE TABLE `sw_modalidad` (
  `id_modalidad` int(11) UNSIGNED NOT NULL,
  `mo_nombre` varchar(64) NOT NULL,
  `mo_activo` tinyint(1) UNSIGNED NOT NULL,
  `mo_orden` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `sw_modalidad`
--

INSERT INTO `sw_modalidad` (`id_modalidad`, `mo_nombre`, `mo_activo`, `mo_orden`) VALUES
(1, 'SEMIPRESENCIAL', 1, 1),
(2, 'BGU INTENSIVO', 1, 3),
(3, 'EGB SUPERIOR INTENSIVA', 1, 2),
(5, 'EBGS VIRTUAL', 0, 4);


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_criterio_personalizado`
--

DROP TABLE IF EXISTS `sw_criterio_personalizado`;
CREATE TABLE `sw_criterio_personalizado` (
  `id_criterio_personalizado` int(11) NOT NULL,
  `id_rubrica_personalizada` int(11) NOT NULL,
  `cp_descripcion` varchar(32) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `cp_ponderacion` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_criterio_personalizado`
--

INSERT INTO `sw_criterio_personalizado` (`id_criterio_personalizado`, `id_rubrica_personalizada`, `cp_descripcion`, `cp_ponderacion`) VALUES
(1, 1, 'PRESENTACION OPORTUNA', 0.25),
(2, 1, 'CONTENIDO DEL TRABAJO', 0.25),
(3, 1, 'ORDEN', 0.25),
(4, 1, 'MATERIAL UTILIZADO', 0.25),
(5, 2, 'ENFOQUE', 0.25),
(6, 2, 'ORGANIZACION', 0.25),
(7, 2, 'CUADROS', 0.25),
(8, 2, 'CREATIVIDAD', 0.25),
(9, 3, 'PRESENTACION', 0.25),
(10, 3, 'CONTENIDO DEL TRABAJO', 0.25),
(11, 3, 'ORGANIZACION', 0.25),
(12, 3, 'MATERIAL UTILIZADO', 0.25),
(13, 4, 'PRESENTACION', 0.2),
(14, 4, 'CONTENIDOS', 0.4),
(15, 4, 'ENTONACION', 0.2),
(16, 4, 'USO DE PAUSAS', 0.2),
(17, 5, 'CONOCIMIENTOS', 1),
(18, 1, 'PRESENTACION OPORTUNA', 0.25),
(19, 1, 'CONTENIDO DEL TRABAJO', 0.25),
(20, 1, 'ORDEN', 0.25),
(21, 1, 'MATERIAL UTILIZADO', 0.25),
(22, 2, 'ENFOQUE', 0.25),
(23, 2, 'ORGANIZACION', 0.25),
(24, 2, 'CUADROS', 0.25),
(25, 2, 'CREATIVIDAD', 0.25);

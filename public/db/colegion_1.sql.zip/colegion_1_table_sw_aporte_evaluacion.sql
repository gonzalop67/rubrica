
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sw_aporte_evaluacion`
--

DROP TABLE IF EXISTS `sw_aporte_evaluacion`;
CREATE TABLE `sw_aporte_evaluacion` (
  `id_aporte_evaluacion` int(11) NOT NULL,
  `id_periodo_evaluacion` int(11) NOT NULL,
  `ap_nombre` varchar(24) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `ap_abreviatura` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `sw_aporte_evaluacion`
--

INSERT INTO `sw_aporte_evaluacion` (`id_aporte_evaluacion`, `id_periodo_evaluacion`, `ap_nombre`, `ap_abreviatura`) VALUES
(1, 1, 'PRIMER PARCIAL', '1er.P.'),
(2, 1, 'SEGUNDO PARCIAL', '2do.P.'),
(3, 1, 'TERCER PARCIAL', '3er.P.'),
(4, 1, 'EXAMEN QUIMESTRAL', 'EQ1'),
(5, 2, 'PRIMER PARCIAL', '1er.P.'),
(6, 2, 'SEGUNDO PARCIAL', '2do.P.'),
(7, 2, 'TERCER PARCIAL', '3er.P.'),
(8, 2, 'EXAMEN QUIMESTRAL', 'EQ2'),
(9, 3, 'SUPLETORIO', 'SUPLE'),
(10, 4, 'REMEDIAL', 'REME'),
(11, 5, 'DE GRACIA', 'GRAC');
